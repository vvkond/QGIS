<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>Dialog</name>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="14"/>
        <source>Настройка диаграмм</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="45"/>
        <source>Диаграммы</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="51"/>
        <source>Размер (мм)</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="57"/>
        <source>Минимальный диаметр</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="64"/>
        <source>Максимальный диаметр</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="101"/>
        <source>Диаграмма жидкости</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="106"/>
        <source>Диаграмма закачки</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="111"/>
        <source>Диаграмма газа</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="116"/>
        <source>Диаграмма конденсата</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="124"/>
        <source>Тип диаграммы</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="131"/>
        <source>Заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="154"/>
        <source>Масштаб</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="162"/>
        <source>Масса</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="167"/>
        <source>Объем</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="192"/>
        <source>кг</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="197"/>
        <source>тонн</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="208"/>
        <source>Компоненты</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="221"/>
        <source>Добыча нефти</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="229"/>
        <source>Добыча газа</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="237"/>
        <source>Добыча воды</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="245"/>
        <source>Добыча конденсата</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="253"/>
        <source>Закачка газа</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="261"/>
        <source>Закачка воды</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="269"/>
        <source>Газлифт</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="277"/>
        <source>Свободный газ</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="297"/>
        <source>Цвет линии</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="304"/>
        <source>Цвет фона</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="311"/>
        <source>Подписи</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="336"/>
        <source>Цвет</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="350"/>
        <source>Размер</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="357"/>
        <source>Точность</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_prodsetup_base.ui" line="379"/>
        <source>%1-%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="386"/>
        <source>Шаблон</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="393"/>
        <source>Добавить компонент в шаблон</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="396"/>
        <source>Добавить</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="406"/>
        <source>В процентах</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="435"/>
        <source>Общее</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="441"/>
        <source>Сноски</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_prodsetup_base.ui" line="451"/>
        <source>Среднесуточная добыча</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PDSProductionBase</name>
    <message>
        <location filename="../qgis_pds_production_base.ui" line="14"/>
        <source>Map of current production</source>
        <translation>Карта текущей добычи</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_production_base.ui" line="55"/>
        <source>Пласты</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_production_base.ui" line="95"/>
        <source>Период</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production_base.ui" line="101"/>
        <source>Last date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production_base.ui" line="135"/>
        <source>dd.MM.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_production_base.ui" line="118"/>
        <source>Начальная дата</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_production_base.ui" line="125"/>
        <source>Конечная дата</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production_base.ui" line="145"/>
        <source>First date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QgisPDS</name>
    <message>
        <location filename="../bblInit.py" line="25"/>
        <source>Crude oil</source>
        <translation>Сырая нефть</translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="28"/>
        <source>Natural gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="31"/>
        <source>Produced water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="34"/>
        <source>Condensate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="37"/>
        <source>Injected gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="40"/>
        <source>Injected water</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="43"/>
        <source>Lift gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bblInit.py" line="46"/>
        <source>Free gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="286"/>
        <source>&amp;PDS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="239"/>
        <source>Select PDS project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="239"/>
        <source>Select project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="247"/>
        <source>Load wells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="254"/>
        <source>Load current production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="261"/>
        <source>Load production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds.py" line="276"/>
        <source>Production setup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QgisPDSDialog</name>
    <message>
        <location filename="../qgis_pds_dialog.py" line="172"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_dialog.py" line="100"/>
        <source>File not exists - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_dialog.py" line="172"/>
        <source>Connection {0}: {1}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context encoding="UTF-8">
    <name>QgisPDSDialogBase</name>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_dialog_base.ui" line="14"/>
        <source>Выбор проекта</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_dialog_base.ui" line="49"/>
        <source>Хост</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_dialog_base.ui" line="54"/>
        <source>Сервер</source>
        <translation type="unfinished"></translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../qgis_pds_dialog_base.ui" line="59"/>
        <source>Проект</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QgisPDSProductionDialog</name>
    <message>
        <location filename="../qgis_pds_production.py" line="55"/>
        <source>Map of cumulative production</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="729"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="271"/>
        <source>No current PDS project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="274"/>
        <source>Current PDS project: {0}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="729"/>
        <source>Read production from project {0}: {1}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="190"/>
        <source>Layer create error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="304"/>
        <source>Reservoir is not selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="355"/>
        <source>Layer: {0} refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="377"/>
        <source>calcProds: zero time value for well </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="377"/>
        <source>QGisPDS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_production.py" line="480"/>
        <source>No fluid for </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QgisPDSWells</name>
    <message>
        <location filename="../qgis_pds_wells.py" line="142"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_wells.py" line="45"/>
        <source>Error create wells layer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_wells.py" line="62"/>
        <source>No current PDS project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_wells.py" line="100"/>
        <source>Layer: {0} refreshed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qgis_pds_wells.py" line="142"/>
        <source>Read wells from project {0}: {1}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
